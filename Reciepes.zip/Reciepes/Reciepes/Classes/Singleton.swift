//
//  Singleton.swift
//  Reciepes
//
//  Created by kishore babu on 15/11/23.
//

import Foundation
public class Singleton
{
    public static var shared = Singleton()
    
    private init() {}
    
    var MEAL_ID = ""
  
}
