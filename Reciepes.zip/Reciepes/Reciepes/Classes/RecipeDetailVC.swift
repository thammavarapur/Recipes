//
//  RecipeDetailVC.swift
//  Reciepes
//
//  Created by kishore babu on 15/11/23.
//

import UIKit
import SVProgressHUD

class RecipeDetailVC: UIViewController {
   
    
    @IBOutlet weak var cornerView: UIView!
    @IBOutlet weak var brandImage: UIImageView!
    @IBOutlet weak var productNameLbl: UILabel!
    @IBOutlet weak var backBtn: UIButton!
    
    @IBOutlet weak var descriptionTxtView: UITextView!
    
    var recipeID:String!
    private let getRecipeDetailDataSource = RecipeDetailViewModel()
    var recipeDetailData:[DetailMeals] = []
    
    var productIDDict:NSArray! = []
    var getProductByIdStr:String!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        cornerView.clipsToBounds = true
        cornerView.layer.cornerRadius = 10
        cornerView.layer.maskedCorners = [.layerMaxXMinYCorner, .layerMinXMinYCorner]
        
        
        backBtn.setTitle("", for: .normal)
        
        
        
        
        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        SVProgressHUD.show(withStatus: "Loading")
        getRecipeDetailDataSource.delegate = self
        getRecipeDetailDataSource.getRecipeDetailApi()
        
    }
    
    @IBAction func backBtnAction(_ sender: UIButton) {
        self.dismiss(animated: true, completion: nil)
    }
    
}

extension RecipeDetailVC: RecipeDetailModelDelegate
{
    func didRecieveRecipeDetailData(data: RecipeDetailData) {
        print(data.meals!)
        SVProgressHUD.dismiss()
        recipeDetailData = data.meals!
        
        
        
        self.productNameLbl.text = recipeDetailData[0].strMeal
        
        if let assistSecImageURL = URL(string:recipeDetailData[0].strMealThumb ?? "") {
            self.brandImage.sd_setImage(with: assistSecImageURL, completed: nil)
            brandImage.contentMode = .scaleAspectFill
        }
        
        descriptionTxtView.text = recipeDetailData[0].strInstructions
        
        
    }
    
    func didFailRecipeDetailData(error: Error)
    {
        if error.localizedDescription == CONSTANT.CHECK_INTERNET_CONNECTION
        {
            self.showAlertError(titleStr: CONSTANT.ALERT, messageStr: CONSTANT.PLEASE_CHECK_INTERNET_CONNECTION)
        }
        else
        {
            self.showAlertError(titleStr: CONSTANT.ALERT, messageStr: error.localizedDescription)
        }
    }
    
    
}
