//
//  Constant+Strings.swift
//  KirannaX
//
//  Created by prince singh on 8/5/20.
//  Copyright © 2020 None. All rights reserved.
//

import Foundation


typealias CONSTANT = String

extension CONSTANT
{
    
    // MARK: - ExternalStrings
    public static let CHECK_INTERNET_CONNECTION = "Check Internet Connection"
    public static let PLEASE_CHECK_INTERNET_CONNECTION = "Please Check Your Internet Connection"
    public static let OOPS = "Alert!"
    public static let ALERT = "Alert!"
}
