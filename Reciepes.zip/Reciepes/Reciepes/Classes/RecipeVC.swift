//
//  RecipeVC.swift
//  Reciepes
//
//  Created by kishore babu on 15/11/23.
//

import UIKit
import Alamofire
import SDWebImage
import SVProgressHUD


class RecipeVC: UIViewController,UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout {
    
    
    @IBOutlet weak var recipeCV: UICollectionView!
    
    private let getRecipeDataSource = RecipeViewModel()
    var recipeData:[Meals] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let flowLayout = UICollectionViewFlowLayout()
        flowLayout.itemSize = CGSize(width: recipeCV.frame.size.width/2, height: 180)
        flowLayout.minimumInteritemSpacing = 0
        flowLayout.minimumLineSpacing = 0
        flowLayout.scrollDirection = .vertical
        recipeCV.collectionViewLayout = flowLayout
        
        let layout = self.recipeCV.collectionViewLayout as! UICollectionViewFlowLayout
        layout.headerReferenceSize = CGSize(width: 50, height: 60)
        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        SVProgressHUD.show(withStatus: "Loading")
        getRecipeDataSource.delegate = self
        getRecipeDataSource.getRecipeApi()
        
    }
    
    func numberOfSections(in collectionView: UICollectionView) -> Int
    {
         return 1
    }
    
    func collectionView(_ collectionView: UICollectionView,
                        numberOfItemsInSection section: Int) -> Int {
        
        
        return recipeData.count
        
        
    }
    
    func collectionView(
        _ collectionView: UICollectionView,
        cellForItemAt indexPath: IndexPath
    ) -> UICollectionViewCell {
        
        
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath as IndexPath) as! RecipeCVC
        
        
        cell.recipeTitle.text = recipeData[indexPath.row].strMeal ?? ""
        
        if let imageURL = URL(string:recipeData[indexPath.row].strMealThumb!) {
            cell.recipeImage.sd_setImage(with: imageURL, completed: nil)
            
        }
        
        return cell
        
    }
    
    
    
    
    
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath)
    {
        
        let storyBoard = UIStoryboard(name:"Main",bundle:nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "RecipeDetailVC") as! RecipeDetailVC
        vc.recipeID = recipeData[indexPath.row].idMeal ?? ""
        Singleton.shared.MEAL_ID = recipeData[indexPath.row].idMeal ?? ""
        
        vc.modalPresentationStyle = .fullScreen
        self.present(vc, animated: true, completion: nil)
        
        
        
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        
        
        return CGSize(width: recipeCV.frame.size.width/2, height: 180)
        
        
        
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        
        return 0.0
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        
        return 0.0
    }
    
    func collectionView(
        _ collectionView: UICollectionView,
        layout collectionViewLayout: UICollectionViewLayout,
        insetForSectionAt section: Int
    ) -> UIEdgeInsets {
        
        return UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
        
        
    }
    
    
}




class SectionHeader: UICollectionReusableView {
    @IBOutlet weak var sectionHeaderlabel: UILabel!
}

class RecipeCVC: UICollectionViewCell {
    
    
    @IBOutlet weak var recipeImage: UIImageView!
    
    
    
    @IBOutlet weak var recipeTitle: UILabel!
    
    
    
}

extension RecipeVC: RecipeModelDelegate
{
    
    func didRecieveRecipeData(data:RecipeData)
    {
        SVProgressHUD.dismiss()
        print(data.meals!)
        recipeData = data.meals!
        recipeCV.reloadData()
        
        
    }
    
    func didFailRecipeData(error: Error)
    {
        if error.localizedDescription == CONSTANT.CHECK_INTERNET_CONNECTION
        {
            self.showAlertError(titleStr: CONSTANT.ALERT, messageStr: CONSTANT.PLEASE_CHECK_INTERNET_CONNECTION)
        }
        else
        {
            self.showAlertError(titleStr: CONSTANT.ALERT, messageStr: error.localizedDescription)
        }
    }
    
    
}
