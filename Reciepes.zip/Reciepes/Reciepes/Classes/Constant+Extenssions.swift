//
//  Constant+Extenssions.swift
//  KirannaX
//
//  Created by prince singh on 8/5/20.
//  Copyright © 2020 None. All rights reserved.
//

import Foundation
import UIKit
import CoreLocation

extension UITextView {

    func resolveHashTags() {

        // turn string in to NSString
        let nsText = NSString(string: self.text)

        // this needs to be an array of NSString.  String does not work.
        let words = nsText.components(separatedBy: CharacterSet(charactersIn: "#ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_").inverted)

        // you can staple URLs onto attributed strings
        let attrString = NSMutableAttributedString()
        attrString.setAttributedString(self.attributedText)

        // tag each word if it has a hashtag
        for word in words {
            if word.count < 3 {
                continue
            }

            // found a word that is prepended by a hashtag!
            // homework for you: implement @mentions here too.
            if word.hasPrefix("#") {

                // a range is the character position, followed by how many characters are in the word.
                // we need this because we staple the "href" to this range.
                let matchRange:NSRange = nsText.range(of: word as String)

                // drop the hashtag
                let stringifiedWord = word.dropFirst()
                if let firstChar = stringifiedWord.unicodeScalars.first, NSCharacterSet.decimalDigits.contains(firstChar) {
                    // hashtag contains a number, like "#1"
                    // so don't make it clickable
                } else {
                    // set a link for when the user clicks on this word.
                    // it's not enough to use the word "hash", but you need the url scheme syntax "hash://"
                    // note:  since it's a URL now, the color is set to the project's tint color
                    attrString.addAttribute(NSAttributedString.Key.link, value: "hash:\(stringifiedWord)", range: matchRange)
                }

            }
        }

        // we're used to textView.text
        // but here we use textView.attributedText
        // again, this will also wipe out any fonts and colors from the storyboard,
        // so remember to re-add them in the attrs dictionary above
        self.attributedText = attrString
    }
}

extension UITextField {
    func setIcon(_ image: UIImage) {
        let iconView = UIImageView(frame:
            CGRect(x: 10, y: 5, width: 20, height: 20))
        iconView.image = image
        let iconContainerView: UIView = UIView(frame:
            CGRect(x: 20, y: 0, width: 30, height: 30))
        iconContainerView.addSubview(iconView)
        leftView = iconContainerView
        leftViewMode = .always
    }
}
extension UILabel {

    func animate(newText: String, characterDelay: TimeInterval) {

        DispatchQueue.main.async {

            self.text = ""

            for (index, character) in newText.enumerated() {
                DispatchQueue.main.asyncAfter(deadline: .now() + characterDelay * Double(index)) {
                    self.text?.append(character)
                }
            }
        }
    }
    func animateRemove(newText: String, characterDelay: TimeInterval) {

           DispatchQueue.main.async {

               self.text = newText

               for (index, character) in newText.enumerated() {
                   DispatchQueue.main.asyncAfter(deadline: .now() + characterDelay * Double(index)) {
                    if self.text != ""{
                    self.text?.removeLast()
                    }
                   }
               }
           }
       }

}
extension UIImage {

    var getWidth: CGFloat {
        get {
            let width = self.size.width
            return width
        }
    }

    var getHeight: CGFloat {
        get {
            let height = self.size.height
            return height
        }
    }
}
extension UIViewController
{
    
    func json(from object:Any) -> String? {

        guard let data = try? JSONSerialization.data(withJSONObject: object, options: []) else {

            return nil

        }

        return String(data: data, encoding: String.Encoding.utf8)

    }
    
    func statusbarSetting()
    {
        let statusBarView = UIView(frame: CGRect(x: 0, y: 0, width: self.view.frame.width, height: UIApplication.shared.statusBarFrame.height))
        statusBarView.backgroundColor = #colorLiteral(red: 0.09803921569, green: 0.09803921569, blue: 0.09803921569, alpha: 1)
        //statusBarView.backgroundColor = #colorLiteral(red: 0.4235294118, green: 0, blue: 0, alpha: 1)
        
        self.navigationController?.view.addSubview(statusBarView)
    }
    
    func showAlertError(titleStr:String = "Error", messageStr:String)
    {
        let alert = UIAlertController(title: titleStr, message: messageStr, preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
    func showAlert(withMessage message: String? = nil, title: String = "Alert", okayTitle: String = "Ok", cancelTitle: String? = nil,viewController:UIViewController, okCall: @escaping () -> () = { }, cancelCall: @escaping () -> () = { }) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        if let cancelTitle = cancelTitle {
            let cancelAction = UIAlertAction(title: cancelTitle, style: .cancel) { (_) in
                cancelCall()
            }
            alert.addAction(cancelAction)
        }
        let okayAction = UIAlertAction(title: okayTitle, style: .default) { (_) in
            okCall()
        }
        alert.addAction(okayAction)
        viewController.present(alert, animated: true)
    }
    
//    func hideKeyboardWhenTappedAround()
//    {
//        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(UIViewController.dismissKeyboard))
//        view.addGestureRecognizer(tap)
//    }
    
//    @objc func dismissKeyboard()
//    {
//        view.endEditing(true)
//    }
    
    func userInteractionFalse()
    {
        self.view.isUserInteractionEnabled = false
    }
    
    func userInteractionTrue()
    {
        self.view.isUserInteractionEnabled = true
    }
    
    func getMapDirections (latitude:Float,longitude:Float){
        //        let appDomen: String = "comgooglemaps://"
        //        let browserDomen: String = "https://www.google.co.in/maps/dir/"
        //        let directionBody: String = "?saddr=&daddr=\(latitude),\(longitude)&directionsmode=driving"
        //
        //        // Make route with google maps application
        //        if let appUrl = URL(string: appDomen), UIApplication.shared.canOpenURL(appUrl) {
        //            guard let appFullPathUrl = URL(string: appDomen + directionBody) else { return }
        //            UIApplication.shared.open(appFullPathUrl, options:[:], completionHandler:nil)
        //
        //            // If user don't have an application make route in browser
        //        } else if let browserUrl = URL(string: browserDomen), UIApplication.shared.canOpenURL(browserUrl) {
        //            guard let browserFullPathUrl = URL(string: browserDomen + directionBody) else { return }
        //            UIApplication.shared.open(browserFullPathUrl, options:[:], completionHandler:nil)
        //        }
        
        if (UIApplication.shared.canOpenURL(URL(string:"comgooglemaps://")!)) {
            UIApplication.shared.openURL(NSURL(string:
                "comgooglemaps://?saddr=&daddr=\(Float(latitude)),\(Float(longitude))&directionsmode=driving")! as URL)
            
        } else {
            // if GoogleMap App is not installed
            UIApplication.shared.openURL(NSURL(string:
                "https://maps.google.com/?q=\(Float(latitude)),\(Float(longitude))")! as URL)
        }
    }
}
extension UIApplication {
    var statusBarView: UIView? {
        if responds(to: Selector("statusBar")) {
            return value(forKey: "statusBar") as? UIView
        }
        return nil
    }
}

extension UITableView {
    func isLastVisibleCell(at indexPath: IndexPath) -> Bool {
        guard let lastIndexPath = indexPathsForVisibleRows?.last else {
            return false
        }
        
        return lastIndexPath == indexPath
    }
}

extension UIView {
    func shake()
    {
        let animation = CAKeyframeAnimation(keyPath: "transform.translation.x")
        animation.timingFunction = CAMediaTimingFunction(name: CAMediaTimingFunctionName.linear)
        animation.duration = 0.5
        animation.values = [-20.0, 20.0, -20.0, 20.0, -10.0, 10.0, -5.0, 5.0, 0.0 ]
        layer.add(animation, forKey: "shake")
    }
    
    func activityStartAnimating(activityColor: UIColor, backgroundColor: UIColor)
    {
        let backgroundView = UIView()
        backgroundView.frame = CGRect.init(x: 0, y: 0, width: self.bounds.width, height: self.bounds.height)
        backgroundView.backgroundColor = backgroundColor
        backgroundView.tag = 475647
        
        var activityIndicator: UIActivityIndicatorView = UIActivityIndicatorView()
        activityIndicator = UIActivityIndicatorView(frame: CGRect.init(x: 0, y: 0, width: 50, height: 50))
        activityIndicator.center = self.center
        activityIndicator.hidesWhenStopped = true
        activityIndicator.style = UIActivityIndicatorView.Style.gray
        activityIndicator.color = activityColor
        activityIndicator.startAnimating()
        self.isUserInteractionEnabled = false
        
        backgroundView.addSubview(activityIndicator)
        
        self.addSubview(backgroundView)
    }
    
    func activityStopAnimating()
    {
        if let background = viewWithTag(475647)
        {
            background.removeFromSuperview()
        }
        self.isUserInteractionEnabled = true
    }
    
    func hideAndShow(view: UIView, hidden: Bool)
    {
        UIView.transition(with: view, duration: 0.5, options: .transitionCrossDissolve, animations:
            {
                view.isHidden = hidden
        })
    }
    
    
    func hideShow(hidden: Bool)
    {
        UIView.transition(with: self, duration: 0.5, options: .transitionCrossDissolve, animations:
            {
                self.isHidden = hidden
        })
    }
    
    func showCountryView()  {
        
        UIView.animateKeyframes(withDuration: 0.5, delay: 0, options: .calculationModeCubicPaced, animations: {
            
            UIView.addKeyframe(withRelativeStartTime: 0.0, relativeDuration: 0.5) {
                
                self.isHidden = false
                self.transform = .identity
                
            }
            
        }, completion: { finished in
            
        })
        
    }
    
    func hideCountryView()
    {
        UIView.animateKeyframes(withDuration: 0.5, delay: 0, options: .calculationModeCubicPaced, animations: {
            
            UIView.addKeyframe(withRelativeStartTime: 0.0, relativeDuration: 0.5) {
                
                self.transform = CGAffineTransform(scaleX: 0, y: 0)
            }
        }, completion: { finished in
            
            self.isHidden = true
        })
    }
    
    func fadeIn(duration: TimeInterval = 0.5, delay: TimeInterval = 0.0, completion: @escaping ((Bool) -> Void) = {(finished: Bool) -> Void in })
    {
        self.alpha = 0.0
        
        UIView.animate(withDuration: duration, delay: delay, options: UIView.AnimationOptions.curveEaseIn, animations: {
            self.isHidden = false
            self.alpha = 1.0
        }, completion: completion)
    }
    
    func fadeOut(duration: TimeInterval = 0.5, delay: TimeInterval = 0.0, completion: @escaping (Bool) -> Void = {(finished: Bool) -> Void in }) {
        self.alpha = 1.0
        
        UIView.animate(withDuration: duration, delay: delay, options: UIView.AnimationOptions.curveEaseIn, animations: {
            self.alpha = 0.0
        }) { (completed) in
            self.isHidden = true
            completion(true)
        }
    }
    
}
extension UIButton{
    func roundedButton(){
        let maskPath1 = UIBezierPath(roundedRect: bounds, byRoundingCorners: [.bottomRight , .bottomLeft], cornerRadii: CGSize(width: 8, height: 8))
        let maskLayer1 = CAShapeLayer()
        maskLayer1.frame = bounds
        maskLayer1.path = maskPath1.cgPath
        layer.mask = maskLayer1
        
    }
    
}


extension UIButton
{
    func btnUnderline(str:String,btn:UIButton,clr:UIColor){
        let yourAttributes: [NSAttributedString.Key: Any] = [ .font: UIFont.systemFont(ofSize: 14), .foregroundColor: clr, .underlineStyle: NSUnderlineStyle.single.rawValue]
        let attributeString = NSMutableAttributedString(string: str, attributes: yourAttributes)
        btn.setAttributedTitle(attributeString, for: .normal)
    }
    
    func hideAndShow(hidden: Bool)
    {
        UIView.transition(with: self, duration: 0.3, options: .transitionFlipFromTop, animations:
            {
                self.isHidden = hidden
        })
    }
    
    func buttonShake()
    {
        let animation = CAKeyframeAnimation(keyPath: "transform.translation.x")
        animation.timingFunction = CAMediaTimingFunction(name: CAMediaTimingFunctionName.linear)
        animation.duration = 0.6
        animation.values = [-20.0, 20.0, -20.0, 20.0, -10.0, 10.0, -5.0, 5.0, 0.0 ]
        layer.add(animation, forKey: "shake")
    }
}

extension UIPageControl
{
    func hideAndShow(hidden: Bool)
    {
        UIView.transition(with: self, duration: 0.3, options: .transitionCrossDissolve, animations:
            {
                self.isHidden = hidden
        })
    }
}

extension UIColor
{
    convenience init(hexString: String, alpha: CGFloat = 1.0) {
        let hexString: String = hexString.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines)
        let scanner = Scanner(string: hexString)
        if (hexString.hasPrefix("#")) {
            scanner.scanLocation = 1
        }
        var color: UInt32 = 0
        scanner.scanHexInt32(&color)
        let mask = 0x000000FF
        let r = Int(color >> 16) & mask
        let g = Int(color >> 8) & mask
        let b = Int(color) & mask
        let red   = CGFloat(r) / 255.0
        let green = CGFloat(g) / 255.0
        let blue  = CGFloat(b) / 255.0
        self.init(red:red, green:green, blue:blue, alpha:alpha)
    }
    func toHexString() -> String {
        var r:CGFloat = 0
        var g:CGFloat = 0
        var b:CGFloat = 0
        var a:CGFloat = 0
        getRed(&r, green: &g, blue: &b, alpha: &a)
        let rgb:Int = (Int)(r*255)<<16 | (Int)(g*255)<<8 | (Int)(b*255)<<0
        return String(format:"#%06x", rgb)
    }
}

extension String
{
    func isValidEmail() -> Bool
    {
        /*        let regex = try! NSRegularExpression(pattern: "^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$", options: .caseInsensitive)
         return regex.firstMatch(in: self, options: [], range: NSRange(location: 0, length: count)) != nil*/
        
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return emailTest.evaluate(with: self)
        
    }
    

    
}

extension NSString
{
    func isMaxmiumString(maxLength :Int, range :NSRange,string :String) -> Bool
    {
        let currentString: NSString = self
        let newString: NSString =
            currentString.replacingCharacters(in: range, with: string) as NSString
        return newString.length <= maxLength
    }
    
    func isMinimumString(minLength :Int, range :NSRange,string :String) -> Bool
    {
        let currentString: NSString = self
        let newString: NSString =
            currentString.replacingCharacters(in: range, with: string) as NSString
        return newString.length <= minLength
    }
}


extension CALayer
{
    func bottomAnimation(duration:CFTimeInterval)
    {
        let animation = CATransition()
        animation.timingFunction = CAMediaTimingFunction(name: CAMediaTimingFunctionName.easeInEaseOut)
        animation.duration = duration
        animation.type = CATransitionType.push
        animation.subtype = CATransitionSubtype.fromTop
        self.add(animation, forKey: CATransitionType.push.rawValue)
    }
    
    func topAnimation(duration:CFTimeInterval)
    {
        let animation = CATransition()
        animation.timingFunction = CAMediaTimingFunction(name: CAMediaTimingFunctionName.easeInEaseOut)
        animation.duration = duration
        animation.type = CATransitionType.push
        animation.subtype = CATransitionSubtype.fromBottom
        self.add(animation, forKey: CATransitionType.push.rawValue)
    }
}


extension UIView
{
    func pushTransition(_ duration:CFTimeInterval)
    {
        let animation:CATransition = CATransition()
        animation.timingFunction = CAMediaTimingFunction(name:
            CAMediaTimingFunctionName.easeInEaseOut)
        animation.type = CATransitionType.push
        animation.subtype = CATransitionSubtype.fromTop
        animation.duration = duration
        layer.add(animation, forKey: CATransitionType.push.rawValue)
    }
}

/*extension TransitionButton
 {
 func userInteractionFalse()
 {
 self.isUserInteractionEnabled = false
 self.alpha = 0.5
 }
 
 func userInteractionTrue()
 {
 self.isUserInteractionEnabled = true
 self.alpha = 1
 }
 
 }*/

extension UIButton
{
    func interactionFalse()
    {
        self.isUserInteractionEnabled = false
        self.alpha = 0.5
    }
    
    func interactionTrue()
    {
        self.isUserInteractionEnabled = true
        self.alpha = 1
    }
    
}



extension Int
{
    var degreesToRadians: Double
    {
        return Double(self) * .pi / 180
    }
}

extension FloatingPoint
{
    var degreesToRadians: Self
    {
        return self * .pi / 180
    }
    var radiansToDegrees: Self
    {
        return self * 180 / .pi
    }
}

extension UITableView
{
    func reloadWithAnimation()
    {
        self.reloadData()
        let tableViewHeight = self.bounds.size.height
        let cells = self.visibleCells
        var delayCounter = 0
        for cell in cells
        {
            cell.transform = CGAffineTransform(translationX: 0, y: tableViewHeight)
        }
        for cell in cells
        {
            UIView.animate(withDuration: 1.6, delay: 0.08 * Double(delayCounter),usingSpringWithDamping: 0.6, initialSpringVelocity: 0, options: .curveEaseInOut, animations:
                {
                    cell.transform = CGAffineTransform.identity
            }, completion: nil)
            delayCounter += 1
        }
    }
    
    func reloadAnimation()
    {
        self.reloadData()
        var i = 0
        for cell in self.visibleCells
        {
            cell.transform = CGAffineTransform(translationX: 0, y: self.rowHeight/2)
            cell.alpha = 0
            UIView.animate(withDuration: 0.5, delay: 0.09 * Double(i) , options: [.curveEaseInOut], animations:
                {
                    cell.transform = CGAffineTransform(translationX: 0, y: 0)
                    cell.alpha = 1
            }, completion: nil)
            i = i + 1
        }
    }
}

extension CLLocation
{
    public func bearingLocation(to destination: CLLocation) -> Double {
        // http://stackoverflow.com/questions/3925942/cllocation-category-for-calculating-bearing-w-haversine-function
        let lat1 = Double.pi * coordinate.latitude / 180.0
        let long1 = Double.pi * coordinate.longitude / 180.0
        let lat2 = Double.pi * destination.coordinate.latitude / 180.0
        let long2 = Double.pi * destination.coordinate.longitude / 180.0
        
        // Formula: θ = atan2( sin Δλ ⋅ cos φ2 , cos φ1 ⋅ sin φ2 − sin φ1 ⋅ cos φ2 ⋅ cos Δλ )
        // Source: http://www.movable-type.co.uk/scripts/latlong.html
        let rads = atan2(
            sin(long2 - long1) * cos(lat2),
            cos(lat1) * sin(lat2) - sin(lat1) * cos(lat2) * cos(long2 - long1))
        let degrees = rads * 180 / Double.pi
        
        return (degrees+360).truncatingRemainder(dividingBy: 360)
    }
}

private var xoAssociationKey: CLLocation? = nil

/*extension GMSMarker
 {
 var oldCoordinates: CLLocation!
 {
 get
 {
 return objc_getAssociatedObject(self, &xoAssociationKey) as? CLLocation
 }
 set(newValue)
 {
 objc_setAssociatedObject(self, &xoAssociationKey, newValue, objc_AssociationPolicy.OBJC_ASSOCIATION_RETAIN)
 }
 }
 
 }
 
 
 private var xsAssociationKey: CLLocationCoordinate2D? = nil
 
 extension GMSMarker
 {
 var lastCoordinates: CLLocationCoordinate2D!
 {
 get
 {
 return objc_getAssociatedObject(self, &xsAssociationKey) as? CLLocationCoordinate2D
 }
 set(newValue)
 {
 objc_setAssociatedObject(self, &xsAssociationKey, newValue, objc_AssociationPolicy.OBJC_ASSOCIATION_RETAIN)
 }
 }
 
 }*/

extension UIImage
{
    enum JPEGQuality: CGFloat {
        case lowest  = 0
        case low     = 0.25
        case medium  = 0.5
        case high    = 0.75
        case highest = 1
    }
    
    func jpeg(_ jpegQuality: JPEGQuality) -> Data?
    {
        return jpegData(compressionQuality: jpegQuality.rawValue)
    }
    
    func resizeImage() -> UIImage?
    {
        var actualHeight: Float = Float(self.size.height)// Float(image.size.height)
        var actualWidth: Float = Float(self.size.width)
        let maxHeight: Float = 300.0
        let maxWidth: Float = 400.0
        var imgRatio: Float = actualWidth / actualHeight
        let maxRatio: Float = maxWidth / maxHeight
        let compressionQuality: Float = 0.5
        //50 percent compression
        
        if actualHeight > maxHeight || actualWidth > maxWidth {
            if imgRatio < maxRatio {
                //adjust width according to maxHeight
                imgRatio = maxHeight / actualHeight
                actualWidth = imgRatio * actualWidth
                actualHeight = maxHeight
            }
            else if imgRatio > maxRatio {
                //adjust height according to maxWidth
                imgRatio = maxWidth / actualWidth
                actualHeight = imgRatio * actualHeight
                actualWidth = maxWidth
            }
            else {
                actualHeight = maxHeight
                actualWidth = maxWidth
            }
        }
        
        let rect = CGRect(x: 0, y: 0, width: CGFloat(actualWidth), height: CGFloat(actualHeight))
        
        UIGraphicsBeginImageContext(rect.size)
        self.draw(in: rect)
        let img = UIGraphicsGetImageFromCurrentImageContext()
        let imageData = jpegData(compressionQuality: CGFloat(compressionQuality))
        
        //            UIImageJPEGRepresentation(img!,CGFloat(compressionQuality))
        UIGraphicsEndImageContext()
        return UIImage(data: imageData!)!
    }
    
    func convertImageToBase64() -> String
    {
        let imageData = self.jpeg(.lowest)
        let base64String = imageData?.base64EncodedString()
        guard let data = base64String else
        {
            return ""
        }
        return data
    }
}

extension UIImageView
{
    func rotateClockwise()
    {
        UIView.animate(withDuration: 0.5)
        {
            () -> Void in
            self.transform = CGAffineTransform(rotationAngle: CGFloat.pi)
        }
    }
    
    func rotateAnticlockwise()
    {
        
        UIView.animate(withDuration: 0.5)
        {
            () -> Void in
            self.transform = CGAffineTransform(rotationAngle: CGFloat.pi * 2)
        }
    }
}

extension UITextField
{
    @IBInspectable var placeHolderColor: UIColor?
        {
        get
        {
            return self.placeHolderColor
        }
        set
        {
            self.attributedPlaceholder = NSAttributedString(string:self.placeholder != nil ? self.placeholder! : "", attributes:[NSAttributedString.Key.foregroundColor: newValue!])
        }
    }
}

//extension UIView {
//    func roundCorners(corners: UIRectCorner, radius: CGFloat) {
//        let path = UIBezierPath(roundedRect: bounds, byRoundingCorners: corners, cornerRadii: CGSize(width: radius, height: radius))
//        let mask = CAShapeLayer()
//        mask.path = path.cgPath
//        layer.mask = mask
//    }
//}


extension UIView {
    enum Corner:Int {
        case bottomRight = 0,
        topRight,
        bottomLeft,
        topLeft
    }
    
    private func parseCorner(corner: Corner) -> CACornerMask.Element {
        let corners: [CACornerMask.Element] = [.layerMaxXMaxYCorner, .layerMaxXMinYCorner, .layerMinXMaxYCorner, .layerMinXMinYCorner]
        return corners[corner.rawValue]
    }
    
    private func createMask(corners: [Corner]) -> UInt {
        return corners.reduce(0, { (a, b) -> UInt in
            return a + parseCorner(corner: b).rawValue
        })
    }
    
    func roundCorners(corners: [Corner], amount: CGFloat = 10) {
        layer.cornerRadius = amount
        let maskedCorners: CACornerMask = CACornerMask(rawValue: createMask(corners: corners))
        layer.maskedCorners = maskedCorners
    }
}
