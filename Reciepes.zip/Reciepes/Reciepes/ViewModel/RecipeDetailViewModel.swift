//
//  RecipeDetailViewModel.swift
//  Reciepes
//
//  Created by kishore babu on 15/11/23.
//

import Foundation
import Alamofire


protocol RecipeDetailModelDelegate: AnyObject
{
    func didRecieveRecipeDetailData(data: RecipeDetailData)
    func didFailRecipeDetailData(error: Error)
}


class RecipeDetailViewModel: NSObject
{
    weak var delegate: RecipeDetailModelDelegate?
    let sharedInstance = Connection()
    
    
    func getRecipeDetailApi()
    {
        
        
        let url = "https://themealdb.com/api/json/v1/1/lookup.php?i=\(Singleton.shared.MEAL_ID)"
        
        let headers: HTTPHeaders = ["Content-Type": "application/json"]
        sharedInstance.requestPOST(url, params: nil, headers: headers, success:
                                    {
            (JSON) in
            
            let  result :Data? = JSON
            
            if result != nil
            {
                do
                {
                    
                    let response = try JSONDecoder().decode(RecipeDetailData.self, from: result!)
                    print("the show address data res is \(response)")
                    
                    DispatchQueue.main.asyncAfter(deadline: .now() + .seconds(2), execute:
                                                    {
                        self.delegate?.didRecieveRecipeDetailData(data: response)
                    })
                }
                catch let error as NSError
                {
                    self.delegate?.didFailRecipeDetailData(error: error)
                }
            }
            else
            {
                
            }
            
        },
                                   failure:
                                    {
            (error) in
            self.delegate?.didFailRecipeDetailData(error: error)
        })
    }
    
}

