//
//  RecipeViewModel.swift
//  Reciepes
//
//  Created by kishore babu on 15/11/23.
//
import Foundation
import Alamofire


protocol RecipeModelDelegate: AnyObject
{
    func didRecieveRecipeData(data: RecipeData)
    func didFailRecipeData(error: Error)
}


class RecipeViewModel: NSObject
{
    weak var delegate: RecipeModelDelegate?
    let sharedInstance = Connection()
    
    func getRecipeApi()
    {
        
        let url = "https://themealdb.com/api/json/v1/1/filter.php?c=Dessert"
        
        let headers: HTTPHeaders = ["Content-Type": "application/json"]
        sharedInstance.requestPOST(url, params: nil, headers: headers, success:
                                    {
            (JSON) in
            
            let  result :Data? = JSON
            
            if result != nil
            {
                do
                {
                    
                    let response = try JSONDecoder().decode(RecipeData.self, from: result!)
                    print("the show address data res is \(response)")
                    
                    DispatchQueue.main.asyncAfter(deadline: .now() + .seconds(2), execute:
                                                    {
                        self.delegate?.didRecieveRecipeData(data: response)
                    })
                }
                catch let error as NSError
                {
                    self.delegate?.didFailRecipeData(error: error)
                }
            }
            else
            {
                
            }
            
        },
                                   failure:
                                    {
            (error) in
            self.delegate?.didFailRecipeData(error: error)
        })
    }
    
}

