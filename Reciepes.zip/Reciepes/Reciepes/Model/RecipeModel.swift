//
//  RecipeModel.swift
//  Reciepes
//
//  Created by kishore babu on 15/11/23.
//

import Foundation


struct RecipeData : Codable {
    let meals : [Meals]?
    
    enum CodingKeys: String, CodingKey {
        
        case meals = "meals"
    }
    
    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        meals = try values.decodeIfPresent([Meals].self, forKey: .meals)
    }
    
}


// MARK: - Encode/decode helpers



struct Meals : Codable {
    let strMeal : String?
    let strMealThumb : String?
    let idMeal : String?
    
    enum CodingKeys: String, CodingKey {
        
        case strMeal = "strMeal"
        case strMealThumb = "strMealThumb"
        case idMeal = "idMeal"
    }
    
    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        strMeal = try values.decodeIfPresent(String.self, forKey: .strMeal)
        strMealThumb = try values.decodeIfPresent(String.self, forKey: .strMealThumb)
        idMeal = try values.decodeIfPresent(String.self, forKey: .idMeal)
    }
    
}
